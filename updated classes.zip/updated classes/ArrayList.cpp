#include "ArrayList.h"
#include<assert.h>

template<class T>
ArrayList<T>::ArrayList()
{
	elementcount = 0;
	capacity = 5;
	arr = new T[capacity];
}

template<class T>
void ArrayList<T>::append(T val)
{
	if (elementcount == capacity)
	{
		expand();
	}
	arr[elementcount] = val;
	elementcount++;
}

template<class T>
int ArrayList<T>::lenght()
{
	assert(!empty());
	return elementcount;
}

template<class T>
void ArrayList<T>::insertAt(int ind, T val)
{
	assert(ind >= 0 && ind < capacity);
	if (elementcount == capacity)
	{
		expand();
	}
	for (int i = elementcount; i > ind; i--)
	{
		arr[i] = arr[i - 1];
	}
	arr[ind] = val;
	elementcount++;
}

template<class T>
void ArrayList<T>::deleteAt(int ind)
{
	assert(ind >= 0 && ind < capacity && !empty());
	for (int i = ind; i < elementcount - 1; i++)
	{
		arr[i] = arr[i + 1];
	}
	elementcount--;
}

template<class T>
void ArrayList<T>::pop_back()
{
	assert(!empty());
	elementcount--;
}

template<class T>
T& ArrayList<T>::At(int ind)
{
	return arr[ind];
}

template<class T>
T& ArrayList<T>::operator[](const int ind)
{
	return At(ind);
}

template<class T>
void ArrayList<T>::expand()
{
	T* arr2 = new T[capacity * 2];
	for (int i = 0; i < capacity; i++)
	{
		arr2[i] = arr[i];
	}
	capacity *= 2;
	delete[] arr;
	arr = arr2;

}

template<class T>
bool ArrayList<T>::empty()
{
	return elementcount == 0;
}

template<class T>
void ArrayList<T>::clear()
{
	while (!empty())
	{
		pop_back();
	}
}

template<class T>
void ArrayList<T>::swap(T* element1, T* element2)
{
	T temp = *element1;
	*element1 = *element2;
	*element2 = temp;
}

template<class T>
void ArrayList<T>::sort()
{
	for(int i=0;i<elementcount-1;i++)
	{
		for(int j=0;j<elementcount-i-1;j++)
		{
			if(arr[j]<arr[j+1])
			{
				swap(&arr[j], &arr[j + 1]);
			}
		}
	}
}

template<class T>
ArrayList<T>::~ArrayList()
{
	clear();
}

