#pragma once
#include<iostream>
#include"NewsFeed.h"
#include"TimeLine.h"
using namespace std;
class User
{
private:
	string name;
	string email;
	string password;
	string gender;
	string birthdate;
	static int idgenerator;
	int userId;
	string work;
	string education;
	string lives_in;
	TimeLine userTimeLine;
	NewsFeed userNewsFeed;

	ArrayList<User>friends;
public:
	User(string name, string email, string password, string gender, string birthdate, string work, string education, string lives_in);
	User();
	friend ostream& operator<<(ostream& os, const User& obj);//operator overloading
	void setName(string name);
	void setGender(string gender);
	void setBirthdate(string birthdate);
	void setWork(string newWork);
	void setEducation(string newEdu);
	string getName();
	string getGender();
	string getBirhtdate();
	string getWork();
	string getEducation();
	string getLives_in();
	NewsFeed getUserNewsFeed();
	TimeLine getUserTimeLine();
	void addPost(Post);
	void removePost();
	void editPost();
	void addFriend(User& newfriend);

};
