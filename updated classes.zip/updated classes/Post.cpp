#pragma warning(disable: 4996)
#include "Post.h"
int Post::cntlikes = 0;
int Post::idgenerator = 0;
Post::Post(string content,string userName)
{
	this->postId = idgenerator;
	this->postTime = time(0);
	this->content = content;
	this->userName=userName;
	idgenerator++;
}

Post::Post()
{
	this->postId = idgenerator;
	idgenerator++;
}

void Post::addLike(int likeid)
{
	bool found = 0;
	for (int i = 0; i < likes.count(); i++)
	{
		if (likeid == likes.at(i))
		{
			likes.deleteAt(i);
			found = true;
			cntlikes--;
		}
	}
	if (found == false)
	{
		likes.appned(likeid);
		cntlikes++;
	}
}
void Post::writeComment(Comments comment)
{
	comments.append(comment);
}
string Post::getDateTime()
{
	return (ctime(&postTime));
}

int Post::getPostId()
{
	return this->postId;
}


string Post::getContent()
{
	return string(this->content);
}

int Post::getLikeCount()
{
	return  cntlikes;
}

bool Post::operator<(const Post& post1)
{
	return this->postId<post1.postId;
}

bool Post::operator>(const Post& post1)
{
	return this->postId>post1.postId;
}

void Post::editpost(string content)
{
	this->content = content;
}

