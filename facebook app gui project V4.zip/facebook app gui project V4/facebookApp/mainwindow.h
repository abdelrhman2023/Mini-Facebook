#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include<vector>
#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

#include"User.h"
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void onAddPostTimeline();
    void onAddPostNewsFeed();
    void onAddPostComment();
    void getPostContent();
    void goToComments();


private slots:

    void on_signupbuttonsignupwidget_clicked();

    void on_loginbuttonsignupform_clicked();

    void on_timelinebutton_clicked();

    void on_signupbuttonsignupform_2_clicked();

    void on_logoutbutton_clicked();


    void on_newsfeedbutton_clicked();

    void on_backoncommentpage_clicked();

private:
    Ui::MainWindow *ui;
    QString buttonstyle="QPushButton {"
                   "background-color: rgb(88, 144, 255);"
                   "border:2px solid rgb(88, 144, 255);"
                   "border-radius:10px;"
                   "color:#fff;" "}"
                   "QPushButton:hover {"
                   "background-color: rgb(47, 116, 251);""}";
    vector<User>allusers;




};
#endif // MAINWINDOW_H
