#include "mainwindow.h"
#include "ui_mainwindow.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
    this->setGeometry(700,50,550,950);
          QObject::connect(
          ui->publishbuttontimeline_2, &QPushButton::clicked,
          this, &MainWindow::onAddPostTimeline);

          QObject::connect(
          ui->publishbuttonnewsfeed, &QPushButton::clicked,
          this, &MainWindow::onAddPostNewsFeed);

          QObject::connect(
          ui->publishbuttoncomment, &QPushButton::clicked,
          this, &MainWindow::onAddPostComment);


}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_signupbuttonsignupwidget_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);

}


void MainWindow::on_loginbuttonsignupform_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_timelinebutton_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(0);

}

void MainWindow::on_signupbuttonsignupform_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
    QString email=ui->emailtextsignupform->text();
    QString password=ui->passwordtextsignupform->text();
    QString username=ui->usernametextboxsignupform->text();
    QString education=ui->educationtextboxsignupform->text();
    QString birthdate=ui->birthdatetextboxsignupform->text();
    QString work=ui->worktextboxsignupform->text();
    QString livein= ui->liveintextboxsignupform->text();
    QString gender=ui->gendertextboxsignupform->text();

    ui->usernamedisplaytimeline_2->setText(username);
    ui->educationdisplaytimeline_2->setText(education);
    ui->birthdaydisplaytimeline_2->setText(birthdate);
    ui->workdisplaytimeline_5->setText(work);
    ui->liveindisplaytimeline_6->setText(livein);
    ui->genderdisplaytimeline_2->setText(gender);

    allusers.push_back(User (username.toStdString(),email.toStdString(),
             password.toStdString(),gender.toStdString(),birthdate.toStdString(),
             work.toStdString(),education.toStdString(),livein.toStdString()));
    //getdata(username,email,password,gender,birthdate,work,education,livein);




}


void MainWindow::on_logoutbutton_clicked()
{

    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::onAddPostTimeline()
{
    //define BoxLayout and each post block
    QVBoxLayout*Layout=qobject_cast<QVBoxLayout*>(ui->scrollareapoststimeline->layout());
    QWidget*postblock=new QWidget();
    QBoxLayout*boxlayout=new QBoxLayout(QBoxLayout::TopToBottom,postblock);
    postblock->setMaximumHeight(220);
    postblock->setMinimumHeight(220);
    postblock->setStyleSheet("background-color: rgb(117, 118, 131);border-radius:20px;");

    //post owner and post content
    QLabel *postcontent=new QLabel();
    QLabel *postOwner=new QLabel();
    QLabel *postTime=new QLabel();
    QLabel *numOfLikes=new QLabel();
    numOfLikes->setText(tr("Likes: %1").arg(Layout->count()+1));
    postTime->setText("6/4/2021");
    postOwner->setText(ui->usernamedisplaytimeline_2->text());
    postOwner->setStyleSheet("color:rgb(0, 0, 0);font-size:15px");
    postTime->setStyleSheet("color:rgb(0, 0, 0);font-size:15px");
    numOfLikes->setStyleSheet("color:rgb(0, 0, 0);font-size:15px");
    postcontent->setStyleSheet("color:rgb(255, 255, 255);font-size:26px");
    postcontent->setMargin(20);
    postcontent->setText(ui->posttextareatimeline_2->text());

    //button add comment

    QPushButton *commentbutton=new QPushButton("Comments");
    QPushButton *likebutoon=new QPushButton("Like");
    boxlayout->insertWidget(0,postOwner);
    boxlayout->insertWidget(1,postTime);
    boxlayout->insertWidget(2,postcontent);
    boxlayout->insertWidget(3,numOfLikes);
    boxlayout->insertWidget(4,likebutoon);
    boxlayout->insertWidget(5,commentbutton);
    commentbutton->setStyleSheet(buttonstyle);
     likebutoon->setStyleSheet(buttonstyle);

    //add the widgets labels into it

       postblock->setLayout(boxlayout);

    //push the boxlayout which have the post components to the QVBox of the scrollview

    Layout->insertWidget(0,postblock);


         connect(commentbutton, &QPushButton::clicked,this, &MainWindow::goToComments);
         connect(likebutoon, &QPushButton::clicked,this,&MainWindow::getPostContent);
}

void MainWindow::goToComments()
{
  ui->stackedWidget->setCurrentIndex(3);
}
void MainWindow::getPostContent()
{

}

void MainWindow::onAddPostNewsFeed()
{
    //define BoxLayout and each post block
    QVBoxLayout*Layout=qobject_cast<QVBoxLayout*>(ui->scrollareapostsnewsfeed->layout());
    QWidget*postblock=new QWidget();
    QBoxLayout*boxlayout=new QBoxLayout(QBoxLayout::TopToBottom,postblock);
    postblock->setMaximumHeight(220);
    postblock->setMinimumHeight(220);
    postblock->setStyleSheet("background-color: rgb(117, 118, 131);border-radius:20px;");

    //post owner and post content
    QLabel *postcontent=new QLabel();
    QLabel *postOwner=new QLabel();
    QLabel *postTime=new QLabel();
    QLabel *numOfLikes=new QLabel();
    numOfLikes->setText(tr("Likes: %1").arg(Layout->count()+1));
    postTime->setText("6/4/2021");
    postOwner->setText(ui->usernamedisplaytimeline_2->text());
    postOwner->setStyleSheet("color:rgb(0, 0, 0);font-size:15px");
    postTime->setStyleSheet("color:rgb(0, 0, 0);font-size:15px");
    numOfLikes->setStyleSheet("color:rgb(0, 0, 0);font-size:15px");
    postcontent->setStyleSheet("color:rgb(255, 255, 255);font-size:26px");
    postcontent->setMargin(20);
    postcontent->setText(ui->posttextnewsfeed->text());

    //button add comment

    QPushButton *commentbutton=new QPushButton("Comments");
    QPushButton *likebutoon=new QPushButton("Like");

    boxlayout->insertWidget(0,postOwner);
    boxlayout->insertWidget(1,postTime);
    boxlayout->insertWidget(2,postcontent);
    boxlayout->insertWidget(3,numOfLikes);
    boxlayout->insertWidget(4,likebutoon);
    boxlayout->insertWidget(5,commentbutton);
     commentbutton->setStyleSheet(buttonstyle);
     likebutoon->setStyleSheet(buttonstyle);
    //add the widgets labels into it

       postblock->setLayout(boxlayout);

    //push the boxlayout which have the post components to the QVBox of the scrollview

    Layout->insertWidget(0,postblock);
    connect(commentbutton, &QPushButton::clicked,this, &MainWindow::goToComments);
}

void MainWindow::onAddPostComment()
{
    //define BoxLayout and each post block
    QVBoxLayout*Layout=qobject_cast<QVBoxLayout*>(ui->scrollareapostscomments->layout());
    QWidget*commentblock=new QWidget();
    QBoxLayout*boxlayout=new QBoxLayout(QBoxLayout::TopToBottom,commentblock);
    commentblock->setMaximumHeight(150);
    commentblock->setMinimumHeight(150);
    commentblock->setStyleSheet("background-color: rgb(117, 118, 131);border-radius:20px;");

    //post owner and post content
    QLabel *commentcontent=new QLabel();
    QLabel *commentowner=new QLabel();
    commentowner->setText(ui->usernamedisplaytimeline_2->text());
    commentcontent->setStyleSheet("color:rgb(255, 255, 255);font-size:26px");
    commentcontent->setMargin(20);
    commentowner->setStyleSheet("color:rgb(0, 0, 0);font-size:15px");
    commentcontent->setText(ui->commenttextbox->text());

    //button add comment
     boxlayout->insertWidget(0,commentowner);
     boxlayout->insertWidget(1,commentcontent);


      commentblock->setLayout(boxlayout);

    //push the boxlayout which have the post components to the QVBox of the scrollview

    Layout->insertWidget(0,commentblock);


}



void MainWindow::on_newsfeedbutton_clicked()
{
     ui->stackedWidget_2->setCurrentIndex(1);
}


void MainWindow::on_backoncommentpage_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}

