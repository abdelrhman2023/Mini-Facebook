#include "TimeLine.h"

TimeLine::TimeLine()
{
}

void TimeLine::addPost(Post post)
{
    this->Posts.push_back(post);
}

void TimeLine::removePost(int postindex)
{
    Posts.erase(Posts.begin()+postindex);
}

vector<Post> TimeLine::getPosts()
{
    return this->Posts;
}

void TimeLine::editPost(int postindex, string newcontent)
{
    Posts.at(postindex).editpost(newcontent);
}

