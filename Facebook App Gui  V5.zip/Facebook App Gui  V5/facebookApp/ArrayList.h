#ifndef ARRAYLIST_H
#define ARRAYLIST_H
#include<assert.h>


#pragma once
template<class T>
class ArrayList
{
private:
    int elementcount=0, capacity=5;
    T* arr=new T[capacity];
public:
    ArrayList();
    void append(T val){
        if (elementcount == capacity)
        {
            expand();
        }
        arr[elementcount] = val;
        elementcount++;
    }

    int lenght()
    {
        assert(!empty());
        return elementcount;
    }
    void insertAt(int ind, T val)
    {
        assert(ind >= 0 && ind < capacity);
        if (elementcount == capacity)
        {
            expand();
        }
        for (int i = elementcount; i > ind; i--)
        {
            arr[i] = arr[i - 1];
        }
        arr[ind] = val;
        elementcount++;
    }
    void deleteAt(int ind)
    {
        assert(ind >= 0 && ind < capacity && !empty());
        for (int i = ind; i < elementcount - 1; i++)
        {
            arr[i] = arr[i + 1];
        }
        elementcount--;
    }

    void pop_back()
    {
        assert(!empty());
        elementcount--;
    }
    T& At(int ind)
    {
        return arr[ind];
    }
    T& operator[](const int ind)
    {
        return At(ind);
    }
    void expand()
    {
        T* arr2 = new T[capacity * 2];
        for (int i = 0; i < capacity; i++)
        {
            arr2[i] = arr[i];
        }
        capacity *= 2;
        delete[] arr;
        arr = arr2;

    }
    bool empty()
    {
        return elementcount == 0;
    }
    void clear()
    {
        while (!empty())
        {
            pop_back();
        }
    }
    void swap(T* element1, T* element2)
    {
        T temp = *element1;
        *element1 = *element2;
        *element2 = temp;
    }
    void sort()
    {
        for(int i=0;i<elementcount-1;i++)
        {
            for(int j=0;j<elementcount-i-1;j++)
            {
                if(arr[j]<arr[j+1])
                {
                    swap(&arr[j], &arr[j + 1]);
                }
            }
        }
    }
    ~ArrayList()
    {
        clear();
    }
};



#endif // ARRAYLIST_H
