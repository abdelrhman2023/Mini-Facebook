#include "User.h"
int User::idgenerator = 0;

User::User(string name, string email, string password, string gender, string birthdate, string work, string education, string lives_in)
{
    this->name = name;
    this->email = email;
    this->password = password;
    this->gender = gender;
    this->birthdate = birthdate;
    this->work = work;
    this->education = education;
    this->lives_in = lives_in;
    idgenerator += 1;
    this->userId = idgenerator;
    this->userNewsFeed = NewsFeed();
    this->userTimeLine = TimeLine();
}

User::User()
{
}

void User::setName(string name)
{
    this->name = name;
}

void User::setGender(string gender)
{
    this->gender = gender;
}

void User::setBirthdate(string birthdate)
{
    this->birthdate = birthdate;
}

void User::setWork(string newWork)
{
    work.append(newWork);
}

void User::setEducation(string newEdu)
{
    education.append(newEdu);
}

string User::getName()
{
    return this->name;
}

string User::getGender()
{
    return this->gender;
}

string User::getBirhtdate()
{
    return this->birthdate;
}

string User::getWork()
{
    return this->work;
}

string User::getEducation()
{
    return this->education;
}

string User::getLives_in()
{
    return this->lives_in;
}

NewsFeed &User::getUserNewsFeed()
{
    return this->userNewsFeed;
}

TimeLine &User::getUserTimeLine()
{
    return this->userTimeLine;
}

void User::writeCommetn(Comment comment,int postindex)
{
    getUserTimeLine().getTimeLinePosts().at(postindex).writeComment(comment);
}

vector<User> User::getFriends()
{
    return friends;
}

int User::getUserId()
{
    return userId;
}

int User::getFriendsCount()
{
    return friends.size();
}

string User::getCommentcontent(int postindex,int commentindex)
{
    getUserTimeLine().getTimeLinePosts().at(postindex).getComments().at(commentindex).getContent();
}

string User::getCommentdatetime(int postindex, int commentindex)
{
    getUserTimeLine().getTimeLinePosts().at(postindex).getComments().at(commentindex).getDateTime();
}

string User::getCommentusername(int postindex, int commentindex)
{
      getUserTimeLine().getTimeLinePosts().at(postindex).getComments().at(commentindex).getCommentOwner();
}

string User::getEmail()
{
    return this->email;
}

string User::getPassword()
{
    return this->password;
}

void User::addPost(Post post)
{
    userTimeLine.addPost(post);
    userNewsFeed.addPost(post);
}

void User::addFriend(User& newfriend)
{
    friends.push_back(newfriend);
    for (int i = 0; i < newfriend.getUserTimeLine().getTimeLinePosts().size(); i++) {
        this->getUserNewsFeed().addPost(newfriend.getUserTimeLine().getTimeLinePosts().at(i));
    }
}

ostream& operator<<(ostream& os, const User& obj)
{
    os << obj.name;
    return os;
}

