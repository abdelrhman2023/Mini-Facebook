#ifndef POST_H
#define POST_H


#pragma once
#include<iostream>
#include <ctime>
#include"ArrayList.h"
#include<vector>
#include"Comment.h"
#include<QDebug>
using namespace std;
class Post
{
private:

    string userName;
    string content;
    time_t postTime;
    vector<Comment> comments;
    int cntlikes;
    LinkedList<int> likes;
    int postId;
    static int idgenerator;
public:
    Post(string content,string username);
    void writeComment(Comment&);
    void addLike(int likeid);
    void editpost(string);
    string getDateTime();
    int getPostId();
    string getContent();
    int getLikeCount();
    string getUserName();
    vector<Comment>&getComments();
    void SetPostid();
    int getCommentsCounter();
    bool operator< (const Post& post1);


};
#endif // POST_H
