#ifndef NEWSFEED_H
#define NEWSFEED_H


#pragma once
#include"Post.h"
#include<iostream>
using namespace std;
class NewsFeed
{
private:
    vector<Post> Posts;
public:
    NewsFeed();
    void addPost(Post post);
    void removePost(int index);
    void editPost(int index, string newcontent);
    int getPostsCount();
    void movePostToTop();
    vector<Post> &getNewsFeedPosts();

};



#endif // NEWSFEED_H
