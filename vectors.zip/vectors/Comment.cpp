#pragma warning(disable: 4996)
#include "Comment.h"
int Comment::cntlikes = 0;
Comment::Comment(string content,string username)
{
    this->commentTime = time(0);
    this->content = content;
    this->userName=username;
}


void Comment::addLike(int likeid)
{
    bool found = 0;
    for (int i = 0; i < likes.count(); i++)
    {
        if (likeid == likes.at(i))
        {
            likes.deleteAt(i);
            found = true;
            cntlikes--;
        }
    }
    if (found == false)
    {
        likes.appned(likeid);
        cntlikes++;
    }
}

string Comment::getDateTime()
{
    return (ctime(&commentTime));
}

string Comment::getContent()
{
    return string(this->content);
}

string Comment::getCommentOwner()
{
    return this->userName;
}


