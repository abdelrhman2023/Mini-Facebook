#ifndef TIMELINE_H
#define TIMELINE_H


#pragma once
#include <iostream>
#include <string>
#include"Post.h"
#include "ArrayList.h"
using namespace std;
class TimeLine
{
private:
    vector<Post> Posts;
public:
    TimeLine();
    void addPost(Post post);
    void removePost(int index);
    int getPostsCount();
    vector<Post>&getTimeLinePosts();
    void editPost(int index, string newcontent);

};



#endif // TIMELINE_H
