#include "NewsFeed.h"
#include"Post.h"
#include<iostream>
using namespace std;

NewsFeed::NewsFeed()
{
}

void NewsFeed::addPost(Post post)
{
    this->Posts.push_back(post);
}

void NewsFeed::removePost(int postindex)
{
    Posts.erase(Posts.begin()+postindex);
}

void NewsFeed::editPost(int postindex, string newcontent)
{
    Posts.at(postindex).editpost(newcontent);
}

int NewsFeed::getPostsCount()
{
    return Posts.size();
}

void NewsFeed::movePostToTop()
{
    ///////
}

vector<Post> &NewsFeed::getNewsFeedPosts()
{
    return this->Posts;
}




