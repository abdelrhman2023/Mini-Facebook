#pragma warning(disable: 4996)
#include "Post.h"
int Post::idgenerator = 0;
Post::Post(string content,string username)
{
    this->postId = idgenerator;
    this->postTime = time(0);
    this->content = content;
    this->userName=username;
    cntlikes=0;
    idgenerator++;
}

void Post::addLike(int likeid)
{
    bool found = 0;
    for (int i = 0; i < likes.count(); i++)
    {
        if (likeid == likes.at(i))
        {
            likes.deleteAt(i);
            found = true;
            cntlikes--;
        }
    }
    if (found == false)
    {
        likes.appned(likeid);
        cntlikes++;
    }
}
void Post::SetPostid()
{
    this->postId = ++idgenerator;
}
void Post::writeComment(Comment &comment)
{
    comments.push_back(comment);
}
string Post::getDateTime()
{
    return (ctime(&postTime));
}

int Post::getPostId()
{
    return this->postId;
}


string Post::getContent()
{
    return this->content;
}

int Post::getLikeCount()
{
    return  cntlikes;
}

string Post::getUserName()
{
    return this->userName;
}

vector<Comment>&Post::getComments()
{
    return this->comments;
}

int Post::getCommentsCounter()
{
    return this->comments.size();
}

bool Post::operator<(const Post& post1)
{
    return this->postId<post1.postId;
}

void Post::editpost(string content)
{
    this->content = content;
}

//bool operator<(const Post& post1, const Post& post2)
//{
//	return  post1.postId<post2.postId;
//}
