#include "TimeLine.h"

TimeLine::TimeLine()
{
}

void TimeLine::addPost(Post post)
{
    this->Posts.push_back(post);
}

void TimeLine::removePost(int postindex)
{
    Posts.erase(Posts.begin()+postindex);
}

int TimeLine::getPostsCount()
{
    return Posts.size();
}

vector<Post>&TimeLine::getTimeLinePosts()
{
    return this->Posts;
}

void TimeLine::editPost(int postindex, string newcontent)
{
    Posts.at(postindex).editpost(newcontent);
}

